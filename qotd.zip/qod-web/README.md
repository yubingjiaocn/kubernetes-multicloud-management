# Quote of the Day Web

The web tier in teh Quote of the Day app.