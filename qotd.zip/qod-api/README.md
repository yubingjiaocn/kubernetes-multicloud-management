# Quote of the Day API

The API tier of the Quote of the Day application.